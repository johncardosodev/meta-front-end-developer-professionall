// Task 1: Code the timesTwo function declaration

// Task 2: Export the timesTwo function as a module
