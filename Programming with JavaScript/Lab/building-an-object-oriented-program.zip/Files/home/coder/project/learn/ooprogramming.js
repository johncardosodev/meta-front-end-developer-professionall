// Task 1: Code a Person class

// Task 2: Code a Worker class

// Task 3: Code an intern object, run methods
function intern() {

}

// Task 4: Code a manager object, methods
function manager() {
    
}