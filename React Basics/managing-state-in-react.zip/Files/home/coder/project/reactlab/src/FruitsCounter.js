function FruitsCounter() {
    return (
        <h2>Total fruits: 2</h2>
    )
}

export default FruitsCounter;