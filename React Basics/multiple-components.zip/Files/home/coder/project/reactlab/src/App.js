import "./App.css";

function App() {
  return (
    <div>
      <h1>Task: Add three Card elements</h1>
    </div>
  );
}

export default App;
