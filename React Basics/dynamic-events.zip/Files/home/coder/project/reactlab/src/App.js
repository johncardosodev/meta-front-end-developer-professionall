function App() {
  return (
    <div>
      <h1>Task: Add a button and handle a click event</h1>
    </div>
  );
}

export default App;
