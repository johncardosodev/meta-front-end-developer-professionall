function Heading() {
    return (
        <h1>Hello, </h1>
    )
}

export default Heading;
