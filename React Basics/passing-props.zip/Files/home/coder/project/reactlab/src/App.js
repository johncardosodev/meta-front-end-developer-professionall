import Heading from "./Heading";

function App() {
    return (
        <div className="App">
            <Heading />
        </div>
    );
};

export default App;
